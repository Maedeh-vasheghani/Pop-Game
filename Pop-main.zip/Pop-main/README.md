# Pop
Voici pop notre site réalisé par le groupe 5.

Dans ce dossier, vous retrouverez les fichiers :

 index.html qui est notre home page avec le style homepage.css qui lui ai lié

 Ainsi que les fichiers pixel drawer, caesar, snake et puissance qui vous emmèneront vers leur propre fichier respectif dans lequel vous retrouverez les fichiers qui ont permis de créer les divertissements. 
 
