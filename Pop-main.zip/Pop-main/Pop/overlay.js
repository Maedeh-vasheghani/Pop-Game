// const btnScroll = document.querySelector("button");
// const overlay1 = document.querySelector(".overlay-1");

// btnScroll.addEventListener("click", () => {
//     overlay1.style.transform = "translateY(-100vh)";
// });